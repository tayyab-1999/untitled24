

exports.get_landing = function(req, res, next) {
    res.render('landing', { title: 'Express' });
};

exports.submit_login = function(req, res, next) {
    console.log("submit e-mail:", req.body.submit_login);
    res.redirect('/');
};




