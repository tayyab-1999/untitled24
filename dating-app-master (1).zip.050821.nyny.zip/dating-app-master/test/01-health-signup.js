const chai = require("chai");
var assert = require("assert");
const expect = chai.expect;
const app = require("../app");

const chaiHttp = require("chai-http");
chai.use(chaiHttp);

// Register Data
const randomString = (Math.random() + 1).toString(36).substring(7);
const register = {
  name: randomString,
  email: `${randomString}@${randomString}.${randomString}`,
  password: `${randomString}@${randomString}.${randomString}`,
  password_confirmation: `${randomString}@${randomString}.${randomString}`,
  phone: "+000000000001",
  dob: "2001-07-24",
  gender: "male",
  looking_for_gender: "female",
  looking_for_max_age: 18,
  looking_for_min_age: 30,
};
// Register Data end

// Test Cases
suite("Create User Profile", function () {
  suite("Integration tests with chai-http", function () {
    // #1 To test and confim that server is running without any errors
    test("Test GET /health", function (done) {
      chai
        .request(app)
        .get("/health")
        .end(function (err, res) {
          assert.strictEqual(res.status, 200);
          assert.strictEqual(res.text, "OK");
          done();
        });
    });
    // #2 To test Register Flow
    test("Test User Register /register/post", function (done) {
      chai
        .request(app)
        .post("/register/post")
        .set("content-type", "application/json")
        .send(register)
        .end(function (err, res) {
          expect(res).to.redirect;
          expect(res.path, "/login");
          done();
        });
    });
  });
});
