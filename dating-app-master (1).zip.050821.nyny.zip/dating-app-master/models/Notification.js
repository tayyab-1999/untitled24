const connection = require('../mysql/db');
const util = require('util');
const moment = require('moment');
const query = util.promisify(connection.query).bind(connection);

const Notification = {

    createUserNotification: async function (data) {
        const created_at = moment().format('YYYY-MM-DD HH:mm:ss');
        return query("INSERT INTO `notifications` (`user_id`, `message`, `created_at`) " +
            "VALUES('" + data['user_id'] + "', '" + data['message'] + "', " +
            " '" + created_at + "')");
    },

    getNotifications: async function (id) {
        return await query("SELECT * FROM `notifications` WHERE `user_id` = '" + id + "'");
    },
};

module.exports = Notification;
