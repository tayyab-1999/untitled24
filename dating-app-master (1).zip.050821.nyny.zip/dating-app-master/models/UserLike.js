const connection = require('../mysql/db');
const util = require('util');
const moment = require('moment');
const query = util.promisify(connection.query).bind(connection);

const UserLike = {

    isUserAlreadyHaveLikeOrDislike: async function (from, to) {
        return query("SELECT id FROM `user_likes` " +
            "WHERE `from_user_id` = '" + from + "' " +
            "AND `to_user_id` = '" + to + "' LIMIT 1");
    },

    createUserLike: async function (data) {
        const created_at = moment().format('YYYY-MM-DD HH:mm:ss');
        return query("INSERT INTO `user_likes`(`from_user_id`, `to_user_id`, `is_like`,`created_at`) " +
            "VALUES('" + data['from_user_id'] + "', '" + data['to_user_id'] + "'," +
            "'" + data['is_like'] + "','" + created_at + "')");
    },

    updateUserLike: async function (isLike, id) {
        return query("UPDATE `user_likes` " +
            "SET `is_like` = '" + isLike + "' " +
            "WHERE `id` = '" + id + "'");
    },

};

module.exports = UserLike;