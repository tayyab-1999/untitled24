const connection = require('../mysql/db');
const util = require('util');
const moment = require('moment');
const query = util.promisify(connection.query).bind(connection);

const User = {

    ageQuery: () => {
        return " FORMAT(DATEDIFF(CURRENT_DATE(), users.dob) / 365, 0) AS age "
    },

    /**
     * Get Users
     * @returns {Promise.<*>}
     */
    getUsers: async (loggedId, gender, maxAge, minAge) => {
        return await query('SELECT `users`.*, user_likes.is_like, ' + User.ageQuery() + ' FROM `users` ' +
            "LEFT JOIN user_likes on users.id = user_likes.to_user_id AND user_likes.from_user_id = '" + loggedId + "' " +
            "WHERE gender = '" + gender + "' AND `deleted_at` IS NULL " +
            "HAVING age <= '" + maxAge + "' AND age >= '" + minAge + "' LIMIT 20");
    },

    /**
     * Get Specific User
     * @param id
     * @returns {Promise.<*>}
     */
    getUser: async function (id) {
        // console.log("SELECT * FROM `users` WHERE `deleted_at` IS NULL AND `id` = '" + id + "' LIMIT 1");
        return await query("SELECT * FROM `users` WHERE `deleted_at` IS NULL AND `id` = '" + id + "' LIMIT 1");
    },


    /**
     * Checking if email Exist
     * @param email
     * @param id
     * @returns {Promise.<*>}
     */
    isEmailExist: async function (email, id) {
        let where = (id !== 0) ? " AND `id` != '" + id + "' " : '';
        return await query("SELECT *, " + User.ageQuery() + " FROM `users` WHERE `deleted_at` IS NULL " +
            "AND `email` = '" + email + "' " + where + " LIMIT 1");
    },

    /**
     * Update User
     * @param data
     * @param id
     * @returns {Promise.<*>}
     */
    updateUser: async function (data, id) {
        return await query("UPDATE `users` SET " +
            "`name` = '" + data['name'] + "', " +
            "`dob` = '" + data['dob'] + "', " +
            "`phone` = '" + data['phone'] + "', " +
            "`gender` = '" + data['gender'] + "', " +
            "`email` = '" + data['email'] + "', " +
            "`looking_for_gender` = '" + data['looking_for_gender'] + "', " +
            "`looking_for_max_age` = '" + data['looking_for_max_age'] + "', " +
            "`looking_for_min_age` = '" + data['looking_for_min_age'] + "' " +
            "WHERE `id` = '" + id + "'");
    },

    /**
     * Create User
     * @param data
     * @param password
     * @returns {Promise.<*>}
     */
    createUser: async function (data, password) {
        const created_at = moment().format('YYYY-MM-DD HH:mm:ss');
        return query("INSERT INTO `users`(`name`, `email`, `password`, `dob`, `gender`, `phone`, `looking_for_gender`, `looking_for_max_age`, `looking_for_min_age`, `created_at`) " +
            "VALUES('" + data['name'] + "', '" + data['email'] + "', '" + password + "'," +
            "'" + data['dob'] + "', '" + data['gender'] + "', '" + data['phone'] + "', " +
            "'" + data['looking_for_gender'] + "', '" + data['looking_for_max_age'] + "', " +
            "'" + data['looking_for_min_age'] + "', '" + created_at + "')");
    },

    /**
     * Delete User
     * @param id
     * @returns {Promise.<*>}
     */
    deleteUser: async function (id) {
        const deleted_at = moment().format('YYYY-MM-DD HH:mm:ss');
        return await query("UPDATE `users` SET `deleted_at` = '" + deleted_at + "' WHERE `id` = '" + id + "'");
    }
};


module.exports = User;
