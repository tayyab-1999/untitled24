const express = require('express');
const router = express.Router();

const auth = require('../controllers/AuthController');
const home = require('../controllers/HomeController');

// Guest routes
router.get("/health", (req, res) => {
   return res.status(200).send(200);
});
router.get('/login', auth.loginView);
router.post('/login/post', auth.login);
router.get('/logout', auth.logout);
router.get('/register', auth.registerView);
router.post('/register/post', auth.register);
router.get('/profile', auth.profileView);
router.post('/profile/post', auth.profile);
router.get('/delete', auth.profileDelete);

// Auth route..
router.get('/user/:id/like', home.like);
router.get('/user/:id/dislike', home.dislike);
router.get('/', home.home);
router.get('/notification', home.notification);

module.exports = router;
