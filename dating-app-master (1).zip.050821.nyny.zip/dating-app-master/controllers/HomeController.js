const User = require('../models/User');
const UserLike = require('../models/UserLike');
const Notification = require('../models/Notification');

//home
exports.home = async function (req, res, next) {
    if (req.session.loggedUser) {
        const loggedUser = req.session.loggedUser;
        const users = await User.getUsers(
            loggedUser.id,
            loggedUser.looking_for_gender,
            loggedUser.looking_for_max_age,
            loggedUser.looking_for_min_age
        );
        return res.render('landing', {
            users: users
        });
    } else {
        return res.redirect('/login');
    }
};

// like
exports.like = async function (req, res, next) {
    if (!req.session.loggedUser) {
        return res.redirect('/login');
    }

    const from_user_id = req.session.loggedUser.id;
    const to_user_id = req.params.id;

    const isUserLikeAlreadyLikeDislike = await UserLike.isUserAlreadyHaveLikeOrDislike(from_user_id, to_user_id);
    if (isUserLikeAlreadyLikeDislike.length > 0) {
        await UserLike.updateUserLike(1, isUserLikeAlreadyLikeDislike[0].id);
        return res.redirect('/');
    }
    await UserLike.createUserLike({
        from_user_id,
        to_user_id,
        is_like: 1,
    });

    const isUserLikeNotification = await UserLike.isUserAlreadyHaveLikeOrDislike(to_user_id, from_user_id);
    if (isUserLikeNotification.length > 0) {
        const toUser = await User.getUser(to_user_id);
        console.log(toUser);
        await Notification.createUserNotification({
            user_id: to_user_id,
            message: `${req.session.loggedUser.name} and you like each other`,
        });
        await Notification.createUserNotification({
            user_id: from_user_id,
            message: `${toUser[0].name} and you like each other`,
        });
    }

    return res.redirect('/');
};

//dislike
exports.dislike = async function (req, res, next) {
    if (!req.session.loggedUser) {
        return res.redirect('/login');
    }

    const from_user_id = req.session.loggedUser.id;
    const to_user_id = req.params.id;

    const isUserLikeAlreadyLikeDislike = await UserLike.isUserAlreadyHaveLikeOrDislike(from_user_id, to_user_id);
    if (isUserLikeAlreadyLikeDislike.length > 0) {
        await UserLike.updateUserLike(0, isUserLikeAlreadyLikeDislike[0].id);
        return res.redirect('/');
    }

    await UserLike.createUserLike({
        from_user_id,
        to_user_id,
        is_like: 0,
    });

    return res.redirect('/');
};

exports.notification = async function (req, res, next) {
    if (!req.session.loggedUser) {
        return res.redirect('/login');
    }

    const notifications = await Notification.getNotifications(req.session.loggedUser.id);
    return res.render('notification', {
        notifications: notifications
    });
};