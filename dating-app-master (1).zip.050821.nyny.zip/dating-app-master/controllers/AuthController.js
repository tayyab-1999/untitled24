const bcrypt = require('bcrypt');
const moment = require('moment');
const User = require('../models/User');
const Validator = require('validatorjs');
const saltRounds = 10;

// Login
exports.loginView = async function (req, res, next) {
    if (req.session.loggedUser) {
        return res.redirect('/');
    }

    return res.render('auth/login', {
        errors: req.flash('errors'),
        inputs: req.flash('inputs')[0] || {}
    });
};

exports.login = async function (req, res, next) {
    req.flash('inputs', req.body);

    const isUserValid = await User.isEmailExist(req.body.email, 0);

    if (isUserValid.length > 0) {
        req.session.loggedUser = isUserValid[0];

        const bcryptResponse = await bcrypt.compare(req.body.password, isUserValid[0].password);
        if (bcryptResponse) {
            return res.redirect('/');
        }
    }

    req.flash('errors', ['The data is not match in record']);

    return res.redirect('/login');
};

//Logout
exports.logout = async function (req, res, next) {
    req.session.destroy();
    return res.redirect('/login');
};
// Register
exports.registerView = function (req, res, next) {
    if (req.session.loggedUser) {
        return res.redirect('/');
    }

    res.render('auth/register', {
        errors: req.flash('errors'),
        inputs: req.flash('inputs')[0] || {},
    });
};
exports.register = async function (req, res, next) {
    req.flash('inputs', req.body);

    let rules = {
        name: 'required',
        email: 'required|email',
        password: 'required|min:6|confirmed',
        phone: 'present|min:12',
        dob: 'required|date',
        gender: 'required',
        looking_for_gender: 'required',
        looking_for_max_age: 'required',
        looking_for_min_age: 'required',
    };


    let validation = new Validator(req.body, rules);
    if (validation.fails()) {
        const errors = [];
        const allErrors = (validation.errors.all());
        Object.keys(allErrors).forEach(function (key) {
            errors.push(allErrors[key][0]);
        });
        req.flash('errors', errors);
        return res.redirect('/register');
    }

    const isEmailAlreadyTaken = await User.isEmailExist(req.body.email, 0);

    if (isEmailAlreadyTaken.length > 0) {
        req.flash('errors', ['The Email is already taken']);
        return res.redirect('/register');
    }

    bcrypt.hash(req.body.password, saltRounds, async (err, hash) => {
        await User.createUser(req.body, hash);
    });

    return res.redirect('/login');
};

//Profile
exports.profileView = function (req, res, next) {
    if (!req.session.loggedUser) {
        return res.redirect('/login');
    }

    const loggedUser = req.session.loggedUser;
    loggedUser.dob = moment(loggedUser.dob).format('YYYY-MM-DD');

    return res.render('auth/profile', {
        errors: req.flash('errors'),
        user: loggedUser,
    });
};

exports.profile = async function (req, res, next) {
    req.flash('inputs', req.body);

    let rules = {
        name: 'required',
        email: 'required|email',
        phone: 'present|min:11',
        dob: 'required|date',
        gender: 'required',
        looking_for_gender: 'required',
        looking_for_max_age: 'required',
        looking_for_min_age: 'required',
    };

    let validation = new Validator(req.body, rules);
    if (validation.fails()) {
        const errors = [];
        const allErrors = (validation.errors.all());
        Object.keys(allErrors).forEach(function (key) {
            errors.push(allErrors[key][0]);
        });
        req.flash('errors', errors);
        return res.redirect('/profile');
    }

    const isEmailAlreadyTaken = await User.isEmailExist(req.body.email, req.session.loggedUser.id);

    if (isEmailAlreadyTaken.length > 0) {
        req.flash('errors', ['The Email is already taken']);
        return res.redirect('/profile');
    }

    await User.updateUser(req.body, req.session.loggedUser.id);

    const loggedUser = await User.getUser(req.session.loggedUser.id);
    req.session.loggedUser = loggedUser[0];

    return res.redirect('/profile');

};

//delete
exports.profileDelete = async function (req, res, next) {
    await User.deleteUser(req.session.loggedUser.id);
    req.session.destroy();
    return res.redirect('/login');
};